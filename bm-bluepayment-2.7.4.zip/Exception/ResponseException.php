<?php

namespace BlueMedia\BluePayment\Exception;

/**
 * Class ResponseException
 * @package BlueMedia\BluePayment\Exception
 */
class ResponseException extends \Exception
{
}
