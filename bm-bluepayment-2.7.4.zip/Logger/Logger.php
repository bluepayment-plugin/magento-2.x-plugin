<?php

namespace BlueMedia\BluePayment\Logger;

/**
 * Class Logger
 *
 * @package   BlueMedia\BluePayment\Logger
 */
class Logger extends \Monolog\Logger
{
}
