define([], function () {
    'use strict';

    return {
        ids: {
            blik: 509,
            smartney: 700,
            hub: 702,
            paypo: 705,
            card: 1500,
            one_click: 1503,
            alior_installments: 1506,
            google_pay: 1512,
            apple_pay: 1513,
            visa_mobile: 1523,
        }
    };
});
