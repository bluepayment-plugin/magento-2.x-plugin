<?php

declare(strict_types=1);

namespace BlueMedia\BluePayment\Helper;

use BlueMedia\BluePayment\Api\Client;
use BlueMedia\BluePayment\Logger\Logger;
use Magento\Framework\App\Config\Initial;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\View\LayoutFactory;
use Magento\Payment\Model\Config;
use Magento\Payment\Model\Method\Factory;
use Magento\Sales\Model\Order;
use Magento\Store\Model\App\Emulation;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;

class Data extends \Magento\Payment\Helper\Data
{
    public const FAILED_CONNECTION_RETRY_COUNT = 5;
    public const MESSAGE_ID_STRING_LENGTH = 32;

    /** @var Logger */
    public $logger;

    /** @var Client */
    public $apiClient;

    /** StoreManagerInterface $storeManager */
    public $storeManager;

    /**
     * Gateways constructor.
     *
     * @param Context $context
     * @param LayoutFactory $layoutFactory
     * @param Factory $paymentMethodFactory
     * @param Emulation $appEmulation
     * @param Config $paymentConfig
     * @param Initial $initialConfig
     * @param Client $apiClient
     * @param Logger $logger
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        Context $context,
        LayoutFactory $layoutFactory,
        Factory $paymentMethodFactory,
        Emulation $appEmulation,
        Config $paymentConfig,
        Initial $initialConfig,
        Client $apiClient,
        Logger $logger,
        StoreManagerInterface $storeManager
    ) {
        parent::__construct(
            $context,
            $layoutFactory,
            $paymentMethodFactory,
            $appEmulation,
            $paymentConfig,
            $initialConfig
        );

        $this->apiClient = $apiClient;
        $this->logger = $logger;
        $this->storeManager = $storeManager;
    }


    /**
     * @param array $data
     * @param int|null $storeId
     *
     * @return string
     */
    public function generateAndReturnHash($data, ?int $storeId = null)
    {
        $algorithm = $this->scopeConfig->getValue(
            'payment/bluepayment/hash_algorithm',
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
        $separator = $this->scopeConfig->getValue(
            'payment/bluepayment/hash_separator',
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
        $values_array = array_values($data);
        $values_array_filter = array_filter(($values_array));
        $comma_separated = implode(",", $values_array_filter);
        $replaced = str_replace(",", $separator, $comma_separated);

        return hash($algorithm, $replaced);
    }

    /**
     * Validate a return/status signature only when service credentials are configured.
     *
     * @param string|int|null $serviceId
     * @param string $orderId
     * @param string|null $sharedKey
     * @param mixed $hash
     * @return bool
     */
    public function isValidReturnHash($serviceId, string $orderId, $sharedKey, $hash): bool
    {
        if (!is_string($hash) || !is_string($sharedKey)
            || empty(trim((string) $serviceId)) || empty(trim($sharedKey))
        ) {
            return false;
        }

        return hash_equals($this->generateAndReturnHash([$serviceId, $orderId, $sharedKey]), $hash);
    }

    /**
     * Sign a continuation link only for an existing order with complete credentials.
     */
    public function generateContinuationHash(Order $order, string $serviceId, string $sharedKey): ?string
    {
        if (!$order->getId() || empty(trim($serviceId)) || empty(trim($sharedKey))) {
            return null;
        }

        return $this->generateAndReturnHash([
            $serviceId,
            $order->getIncrementId(),
            $sharedKey,
        ], (int) $order->getStoreId());
    }

    /**
     * @param int $length
     *
     * @return string
     */
    public function randomString($length = 8)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }

        return $randomString;
    }
}
