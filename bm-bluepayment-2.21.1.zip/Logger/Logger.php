<?php

namespace BlueMedia\BluePayment\Logger;

class Logger extends \Monolog\Logger
{
}
