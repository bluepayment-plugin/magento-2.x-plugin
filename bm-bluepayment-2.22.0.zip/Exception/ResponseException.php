<?php

namespace BlueMedia\BluePayment\Exception;

class ResponseException extends \Exception
{
}
