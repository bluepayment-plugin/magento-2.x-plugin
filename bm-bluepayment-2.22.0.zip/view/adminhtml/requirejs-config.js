/**
 *
 * @type {{map: {*: {bluemediaRefunds: string}}}}
 */
var config = {
    map: {
        '*': {
            bluemediaRefunds: 'BlueMedia_BluePayment/js/refunds'
        }
    }
};