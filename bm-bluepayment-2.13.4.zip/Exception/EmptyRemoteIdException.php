<?php

namespace BlueMedia\BluePayment\Exception;

class EmptyRemoteIdException extends \Exception
{
}
