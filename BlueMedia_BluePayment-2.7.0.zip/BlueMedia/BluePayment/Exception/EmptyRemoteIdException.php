<?php
/**
 * Created by PhpStorm.
 * User: jzembala
 * Date: 10/07/17
 * Time: 09:08
 */

namespace BlueMedia\BluePayment\Exception;

/**
 * Class EmptyRemoteIdException
 * @package BlueMedia\BluePayment\Exception
 */
class EmptyRemoteIdException extends \Exception
{
}