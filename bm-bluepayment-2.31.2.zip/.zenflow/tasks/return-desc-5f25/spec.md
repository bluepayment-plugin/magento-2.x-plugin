# Technical Specification – Refund Failure Reason Display (Magento Autopay Module)

## Task Summary

Extend the Magento 2 Autopay (`BlueMedia_BluePayment`) module so that failed refunds show the concrete failure reason to the merchant, while keeping the existing UX (admin notification “bell” + order comment visible only to admins). To do this, switch refund status polling to the `outDetailsV2` API and surface its status / error information in the module.

**Complexity:** medium (integration with external API, status mapping, and Magento admin messaging, but within an existing, well‑structured module).

---

## Technical Context

- **Platform:** Magento 2.3–2.4, PHP (module `BlueMedia_BluePayment`).
- **Refund flow today:**
  - Refunds are initiated via:
    - Online Credit Memo (`Model\Payment::refund()` → `Helper\Refunds::makeRefund()`), or
    - Manual refund from order view (`Controller\Adminhtml\Refunds\Place` → `Helper\Refunds::makeRefund()`).
  - `Helper\Refunds::makeRefund()`:
    - Builds and sends a refund request to Autopay using `Client::call()` (XML, `transactionRefund` endpoint from `refund_url_*` config).
    - On success:
      - Persists a `blue_refund` row via `saveRefundTransaction()` with:
        - `order_id` (increment id),
        - `remote_id` (original payment remote ID),
        - `message_id` (refund message ID from Autopay),
        - `amount`, `currency`, `is_partial`.
      - Adds an order history comment: *“Refund requested. Message ID: "%1"”*.
  - Pending refund status updates:
    - Collected via `RefundTransactionRepository::getPendingRefundTransactions()` (items with `remote_out_id` unset and a non‑empty `message_id`).
    - Processed by:
      - Cron job `bluepayment_refund_status_updater` (`Cron\RefundStatusUpdater` → `Service\RefundStatusUpdaterService::updateRefundStatuses()`).
      - Or CLI command `bluepayment:refund:update-status` (`Console\Command\UpdateRefundStatusCommand`).
    - `RefundStatusUpdaterService::callApi()`:
      - Fetches `refundStatusUrl` from `ConfigProvider::getRefundStatusUrl()` (currently `/settlementapi/outDetails`).
      - Sends a form‑encoded (XML) request via `Client::call()` with keys `ServiceID`, `MessageID`, `Method`, `Hash`.
    - `RefundStatusUpdaterService::processItem()`:
      - Casts the XML response to an array and reads `Status`.
      - If `Status === 'DONE'`:
        - Gets parent payment transaction (success transaction) via `BlueTransactionRepositoryInterface`.
        - Persists a Magento `sales_payment_transaction` of type `REFUND` via `saveTransaction()`.
        - Calls `updateOrderOnRefund()` to:
          - Set order status to “full refund” or “partial refund” Magento status, based on config:
            - `status_partial_refund`,
            - `status_full_refund`.
          - Add a success history entry (optionally visible to customer).
        - Stores `remoteOutID` on the `blue_refund` row to mark the refund as finished.
      - If `Status === 'ERROR'`:
        - Logs an error.
        - Pushes an admin notification via `addAdminNotification()` with:
          - Title: `"Refund error"`.
          - Description: `"Refund failed. Try again or contact Autopay technical support. (Order: %1, Message ID: %2)"`.
        - **No detailed cause, and no order history comment is added on failure.**
      - Any other status values are effectively treated as “still pending” and are ignored in the current implementation.

- **Autopay documentation (current behavior & desired extension):**
  - Refunds and balance payouts can be queried via `outDetailsV2`:
    - Endpoint: `https://{host_bramki}/settlementapi/outDetails/v2`.
    - HTTP method: `POST`, `Content-Type: application/json`.
    - Request fields (simplified):
      - `serviceId` or `balancePointId` (one required),
      - `messageId`,
      - `method` (`BALANCE_PAYOFF`, `TRANSACTION_REFUND`, `PRODUCT_REFUND`),
      - `hash` (computed as per Autopay hash rules).
    - Response fields (simplified):
      - `serviceId`, `balancePointId`, `messageId`,
      - `status` – one of many enumerated states:
        - `NEW`, `WAITING_FOR_TRANSFER_DATA`, `COMMISSIONS_CALCULATED`, `PROCESSING`, `DONE`,
        - error‑like states, including:
          - `CANCELED_AMOUNT_EXCEEDS_TRANSACTION`,
          - `FAILED_ATTEMPT_OF_BALANCE_CHANGE` (temporary: insufficient funds, Autopay retries for ~30 minutes),
          - `CANCELED_NO_FUNDS_ON_BALANCE` (final cancellation when funds couldn’t be debited for 30 minutes),
          - `CANCELED_MANUALLY_BY_SERVICES`, ...
      - `remoteOutId` – present for `DONE`,
      - `hash` – response integrity,
      - `errorStatus`, `errorStatusCode`, `errorMessages` – optional, filled on technical errors.
  - Business requirement: when a refund fails due to insufficient balance (e.g. `CANCELED_NO_FUNDS_ON_BALANCE`), Magento should receive and expose that reason.

- **Translations:** `i18n/pl_PL.csv` already contains generic refund texts:
  - `"Refund error"`, `"Refund failed. Try again or contact Autopay technical support. (Order: %1, Message ID: %2)"`, `"Refund requested. Message ID: "%1""`.

---

## Implementation Approach

### 1. Switch refund status polling to `outDetailsV2` JSON API

- **Config defaults:**
  - Update `etc/config.xml` to change refund status URLs:
    - `refund_status_url_test` from `.../settlementapi/outDetails` → `.../settlementapi/outDetails/v2`.
    - `refund_status_url_prod` from `.../settlementapi/outDetails` → `.../settlementapi/outDetails/v2`.
  - Keep the config keys themselves unchanged so existing stores do not need manual reconfiguration; only the default values change.

- **API client usage:**
  - Modify `Service\RefundStatusUpdaterService::callApi()` to:
    - Use `Client::callJson()` instead of `Client::call()` (already available and used in `Helper\Webapi`).
    - Build the JSON payload using lower‑camel‑case keys as per docs:
      - `serviceId` from `ConfigProvider::getServiceId($currency, $storeId)` (existing helper).
      - `messageId` from `RefundTransactionInterface::getMessageId()`.
      - `method` as constant `TRANSACTION_REFUND`.
      - Optionally support `balancePointId` in the future; initial implementation can omit it since the module already works on `serviceId`.
    - Compute `hash` using existing config values:
      - Algorithm from `ConfigProvider::getHashAlgorithm($storeId)` (default `sha256`).
      - Separator from `ConfigProvider::getHashSeparator($storeId)` (default `|`).
      - Shared key from `ConfigProvider::getSharedKey($currency, $storeId)`.
      - Hash input sequence aligned with the docs (values in order plus shared key at the end).
    - Send JSON body and parse the decoded array; handle network / parsing errors by logging and treating the item as still pending (no state changes).

- **Response parsing:**
  - Adjust `processItem()` to work with the new JSON structure:
    - Read `$status = $response['status'] ?? null;`.
    - Read `$remoteOutId = $response['remoteOutId'] ?? null;`.
    - Read error‑related fields:
      - `$errorStatus = $response['errorStatus'] ?? null;`
      - `$errorStatusCode = $response['errorStatusCode'] ?? null;`
      - `$errorMessages = $response['errorMessages'] ?? null;`
    - Optionally verify the response `hash` following Autopay guidelines; if invalid, log and skip processing.

### 2. Define refund status handling and mapping

- **Successful refund:**
  - For `status === 'DONE'`:
    - Keep existing behavior:
      - Load parent payment transaction as today.
      - Call `saveTransaction()` to persist the Magento refund transaction.
      - Call `updateOrderOnRefund()` to adjust order status and add the “Refunded %1…” history entry.
      - Set `remote_out_id` on the `blue_refund` row to `remoteOutId` and save it.

- **Pending / in‑progress statuses:**
  - For statuses that mean “in progress” or “waiting”, do nothing (leave refund as pending):
    - `NEW`,
    - `WAITING_FOR_TRANSFER_DATA`,
    - `COMMISSIONS_CALCULATED`,
    - `FAILED_ATTEMPT_OF_BALANCE_CHANGE` (retries up to 30 minutes when balance is insufficient),
    - `PROCESSING`.
  - These items remain in `getPendingRefundTransactions()` and will be checked by the next cron/CLI execution.

- **Final failure statuses (business failure):**
  - Consider at least the following as final, non‑retryable failures:
    - `CANCELED_NO_FUNDS_ON_BALANCE` – no funds on Autopay balance for 30 minutes.
    - `CANCELED_AMOUNT_EXCEEDS_TRANSACTION` – sum of refunds exceeds transaction amount (integration misuse or concurrency).
    - `CANCELED_MANUALLY_BY_SERVICES` – manually canceled on Autopay side before funds were debited.
  - Behavior for these statuses:
    - Log a structured error (status, errorStatus, errorStatusCode, errorMessages, messageId, orderId).
    - Generate an admin notification with a description that includes:
      - Order increment ID,
      - Message ID,
      - Autopay status code,
      - Where available, `errorStatus` and/or `errorMessages`.
    - Add an order history comment (not customer‑visible) carrying the same reason.
    - **For now, keep the existing persistence contract for `blue_refund`:**
      - Do not introduce schema changes.
      - Whether to mark the refund as “finished” by setting `remote_out_id` for failures is an implementation choice:
        - Safer, minimal‑change approach: follow current behavior for `Status === 'ERROR'` and leave `remote_out_id` unset, accepting that such refunds may remain in the pending list but will simply re‑create the same notification if processed again.
        - If we decide to stop reprocessing failures, we can set `remoteOutId` to a recognizable value (e.g. the Autopay status code) and adjust future code carefully; this would be a small behavioral change and should be agreed with stakeholders before implementation.

- **Technical / protocol errors:**
  - If the API responds with an unexpected shape or without `status`, or if `errorStatus`/`errorStatusCode` indicate a protocol error:
    - Log the full payload.
    - Produce a generic notification similar to the existing one, optionally including `errorStatus` or `errorStatusCode`.
    - Add an order comment with the generic error, consistent with the new pattern.

### 3. Build reusable failure‑reason formatting

- Introduce a small, internal formatter in `RefundStatusUpdaterService` to produce human‑readable messages from the Autopay response:
  - Input: `$status`, `$errorStatus`, `$errorStatusCode`, `$errorMessages`, order increment id, message id.
  - Output: an English, translatable string suitable as:
    - Admin notification description.
    - Order history comment.
- Example formatting strategy:
  - For `CANCELED_NO_FUNDS_ON_BALANCE`:
    - *“Refund failed due to insufficient funds on Autopay balance (status: %1, order: %2, message ID: %3).”*
  - For `CANCELED_AMOUNT_EXCEEDS_TRANSACTION`:
    - *“Refund failed because the total refund amount exceeds the transaction amount (status: %1, order: %2, message ID: %3).”*
  - For `CANCELED_MANUALLY_BY_SERVICES`:
    - *“Refund was canceled manually in the Autopay system (status: %1, order: %2, message ID: %3).”*
  - For other statuses:
    - *“Refund failed with status %1 (order: %2, message ID: %3). Additional information: %4”* where `%4` is built from `errorStatus`, `errorStatusCode`, `errorMessages` if present.
- Use this formatter for:
  - Admin notification description (via `addAdminNotification()`).
  - Order history comment (`$order->addCommentToStatusHistory($formattedMessage);`).

### 4. Update Magento admin notification and order comment behavior

- **Admin notification (“bell”):**
  - Keep using `addMajor()` via `addAdminNotification()` but change:
    - The description to include the formatted reason.
    - Optionally keep the existing generic text as a fallback when no detailed status is available.
  - Example description (conceptually):
    - *“Refund failed due to insufficient funds on Autopay balance (Order: %1, Message ID: %2, Status: %3).”*

- **Order history comment (admin‑only):**
  - For each final failure, add a comment:
    - Use the same formatted text as the notification (or a slightly more detailed variant).
    - Use `addCommentToStatusHistory()` without customer notification, so the comment is visible only in the admin order view.

- **Success path:**
  - Leave existing success behavior unchanged (admin sees existing success comments and no extra notification).

### 5. Translations and user‑visible strings

- Extend `i18n/pl_PL.csv` with new keys for:
  - Detailed failure messages / templates, e.g.:
    - `"Refund failed due to insufficient funds on Autopay balance (Order: %1, Message ID: %2, Status: %3)"`
    - `"Refund failed because the total refund amount exceeds the transaction amount (Order: %1, Message ID: %2, Status: %3)"`
    - `"Refund was canceled manually in the Autopay system (Order: %1, Message ID: %2, Status: %3)"`
    - `"Refund failed with status %1 (Order: %2, Message ID: %3). Additional information: %4"`
  - Keep existing generic messages for backward compatibility and as fallbacks.
- Ensure any new messages are wrapped in `__()` and follow existing translation patterns.

### 6. Documentation updates (optional but recommended)

- Update `README_EN.md` / `README.md` in the “Refunds” section to mention:
  - That failed refunds now show a more detailed reason in:
    - Admin notifications.
    - Order history (admin‑only comments).
  - Example explanation for the no‑funds case (`CANCELED_NO_FUNDS_ON_BALANCE`).

---

## Source Code Structure Changes

The implementation will modify the following existing files (no new PHP classes anticipated):

- `etc/config.xml`
  - Change defaults for `refund_status_url_test` and `refund_status_url_prod` to `/settlementapi/outDetails/v2`.

- `Model/ConfigProvider.php`
  - `getRefundStatusUrl()` behavior stays the same; it will automatically use the new default URLs. No code change needed beyond potentially clarifying docblocks if desired.

- `Service/RefundStatusUpdaterService.php`
  - **`callApi()`**
    - Switch to `Client::callJson()` and JSON payload (`serviceId`, `messageId`, `method`, `hash`).
    - Compute `hash` as per Autopay docs using existing config helpers.
  - **`processItem()`**
    - Adjust to read `status` (lowercase) and JSON response fields.
    - Implement status classification (success, pending, final failure).
    - Add calls to a new internal formatter + order comment creation for final failures.
  - **New private helper(s)** (within the same class):
    - `buildFailureDescription(...)` (or equivalent) to format human‑readable failure reason from the response.

- `i18n/pl_PL.csv`
  - Add new translation strings for detailed refund failure messages.

- `README_EN.md` / `README.md` (optional)
  - Amend refund documentation to describe the new behavior.

No changes are planned in:

- `Helper\Refunds` (refund initiation logic),
- `Cron\RefundStatusUpdater` / `Console\Command\UpdateRefundStatusCommand` (they will call the updated service transparently),
- Database schema (`etc/db_schema.xml`) – the `blue_refund` structure remains unchanged.

---

## Data Model / API / Interface Changes

- **Data model:**
  - No schema changes.
  - `blue_refund` continues to hold:
    - `order_id`, `remote_id`, `message_id`, `remote_out_id`, `amount`, `currency`, `is_partial`.
  - Final failure state handling:
    - Initially, we will keep current behavior and *not* change `remote_out_id` for failures, unless agreed otherwise, to avoid altering how “pending” vs “finished” is interpreted today.

- **External API:**
  - Refund status polling will move from:
    - `.../settlementapi/outDetails` (legacy, form‑encoded/XML)
  - To:
    - `.../settlementapi/outDetails/v2` (JSON, documented as `outDetailsV2`).
  - Request/response formats will match the official documentation, using:
    - JSON body with `serviceId`, `messageId`, `method`, `hash`.
    - JSON response with `status`, `remoteOutId`, `errorStatus`, `errorStatusCode`, `errorMessages`, and `hash`.

- **Magento admin UX:**
  - **Admin notification:**
    - Still triggered via the existing notification system.
    - Description text will now include the specific reason (Autopay status, optionally error details), especially for:
      - No funds (`CANCELED_NO_FUNDS_ON_BALANCE`),
      - Amount exceeds transaction,
      - Manual cancellation.
  - **Order history:**
    - On final failure, a new history comment is added, containing the same reason.
    - Comment is admin‑only (no customer notification).

---

## Verification Approach

Because this is a Magento module, full functional verification requires a running Magento 2 instance with the module installed and connected to Autopay (test environment recommended).

### 1. Static checks

- Run PHP syntax checks (from the Magento root, or in CI):
  - `php -l` on modified PHP files.
- If available in the project:
  - Run PHP_CodeSniffer or other linters configured for the module.

### 2. Integration / functional testing

On a Magento 2 test instance with Autopay test credentials:

1. **Happy path refund still works:**
   - Place an order paid via Autopay.
   - Initiate a refund (Credit Memo online or “Autopay return” button).
   - Ensure:
     - A “Refund requested” comment is added with Message ID.
     - Cron / CLI `bin/magento bluepayment:refund:update-status` marks the refund as `DONE`:
       - Magento payment transaction for the refund is created.
       - Order status is updated according to full/partial refund config.
       - No error notification is produced.

2. **No‑funds scenario (`CANCELED_NO_FUNDS_ON_BALANCE`):**
   - Prepare an Autopay test configuration where the balance is insufficient (per Autopay support/test instructions), or simulate using a test case that forces this status.
   - Initiate a refund.
   - After the Autopay processing window (up to ~30 minutes, or using a pre‑configured test case that returns this status faster), run:
     - `bin/magento bluepayment:refund:update-status`.
   - Verify:
     - An admin notification appears in the Magento “bell”:
       - Title “Refund error” (or equivalent).
       - Description includes the specific reason and Autopay status (e.g. `CANCELED_NO_FUNDS_ON_BALANCE`).
     - The order’s history contains an admin‑only comment with the same reason.

3. **Other failure statuses (e.g. `CANCELED_AMOUNT_EXCEEDS_TRANSACTION`):**
   - Attempt an invalid refund (e.g. multiple concurrent partial refunds exceeding transaction amount) to produce the relevant status.
   - Run the refund status update (cron or CLI).
   - Verify the notification and order comment include the appropriate mapped or generic error message and the Autopay status code.

4. **Intermediate statuses:**
   - For a just‑initiated refund, call `bin/magento bluepayment:refund:update-status` while the refund is still in progress.
   - Confirm:
     - No failure notification is created.
     - No failure order comment is created.
     - The refund remains pending and will later transition to either success or a final failure state.

5. **Regression checks:**
   - Confirm that:
     - Other module features (payments, ITN processing, configuration pages, gateway list synchronization) still work as before.
     - Existing refund error flows still produce at least the generic notification if no detailed status is available.

---

## Next Steps

1. Implement the changes described above in:
   - `etc/config.xml`,
   - `Service/RefundStatusUpdaterService.php`,
   - `i18n/pl_PL.csv`,
   - Optionally, `README_EN.md` / `README.md`.
2. Deploy to a test Magento instance, configure Autopay test credentials, and run the verification scenarios.
3. Refine messages / mappings with product/QA feedback, especially for new statuses introduced by `outDetailsV2`.

