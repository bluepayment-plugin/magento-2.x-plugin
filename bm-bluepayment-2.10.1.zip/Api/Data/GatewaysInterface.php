<?php
/**
 * Created by PhpStorm.
 * User: piotr
 * Date: 29.11.2016
 * Time: 12:06
 */

namespace BlueMedia\BluePayment\Api\Data;

/**
 * Interface GatewaysInterface
 */
interface GatewaysInterface
{
}
